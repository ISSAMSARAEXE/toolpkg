apt update -y
apt upgrade -y
apt install python2 -y
apt install python2-dev -y
apt install python3 -y
apt install java -y
apt install fish -y
apt install ruby -y
apt install help -y
apt install git -y
apt install host -y
apt install php -y
apt install perl -y 
apt install nmap -y 
apt install bash -y 
apt install clang -y 
apt install nano -y
apt install w3m -y 
apt install havij -y 
apt install hydra -y 
apt install figlet -y 
apt install cowsay -y
apt install curl -y
apt install tar -y
apt install zip -y
apt install unzip -y
apt install tor -y
apt install google -y
apt install sudo -y
apt install wget -y
apt install wireshark -y
apt install wgetrc -y
apt install wcalc -y
apt install bmon -y
apt install vpn -y
apt install unrar -y
apt install toilet -y
apt install proot -y
apt install net-tools -y
apt install golang -y
apt install chroot -y
termux-chroot -y
apt install macchanger -y
apt install openssl -y
apt install cmatrix -y
apt install openssh -y
apt install wireshark -y
termux-setup-storage -y
apt install macchanger -y
apt update && apt upgrade 
python3 go.py