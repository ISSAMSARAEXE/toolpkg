import os
import time
os.system('clear')
    
v ='\033[0;35m'
W  = '\33[0m'
R  = '\33[1;31m'
G  = '\33[1;32m'
O  = '\33[1;33m'
B  = '\33[1;34m'
P  = '\33[1;35m'
C  = '\33[1;36m'
GR = '\33[1;37m'
def tool():
    bnr =(R+"""
'##::::'##:'########::'########:::::'###::::'########:'########:
 ##:::: ##: ##.... ##: ##.... ##:::'## ##:::... ##..:: ##.....::
 ##:::: ##: ##:::: ##: ##:::: ##::'##:. ##::::: ##:::: ##:::::::
 ##:::: ##: ########:: ##:::: ##:'##:::. ##:::: ##:::: ######:::
 ##:::: ##: ##.....::: ##:::: ##: #########:::: ##:::: ##...::::
 ##:::: ##: ##:::::::: ##:::: ##: ##.... ##:::: ##:::: ##:::::::
. #######:: ##:::::::: ########:: ##:::: ##:::: ##:::: ########:
:.......:::..:::::::::........:::..:::::..:::::..:::::........::

""")
    #print(bnr)
    bnrx=(R+"""
 /$$$$$$$$ /$$$$$$   /$$$$$$  /$$        /$$$$$$ 
|__  $$__//$$__  $$ /$$__  $$| $$       /$$__  $$
   | $$  | $$  \ $$| $$  \ $$| $$      | $$  \__/
   | $$  | $$  | $$| $$  | $$| $$      |  $$$$$$ 
   | $$  | $$  | $$| $$  | $$| $$       \____  $$
   | $$  | $$  | $$| $$  | $$| $$       /$$  \ $$
   | $$  |  $$$$$$/|  $$$$$$/| $$$$$$$$|  $$$$$$/
   |__/   \______/  \______/ |________/ \______/ 
                                                 
    	""")
    print(bnrx)
    bnr1 = (R+"""
 █    ██  ██▓███  ▓█████▄  ▄▄▄     ▄▄▄█████▓▓█████ 
 ██  ▓██▒▓██░  ██▒▒██▀ ██▌▒████▄   ▓  ██▒ ▓▒▓█   ▀ 
▓██  ▒██░▓██░ ██▓▒░██   █▌▒██  ▀█▄ ▒ ▓██░ ▒░▒███   
▓▓█  ░██░▒██▄█▓▒ ▒░▓█▄   ▌░██▄▄▄▄██░ ▓██▓ ░ ▒▓█  ▄ 
▒▒█████▓ ▒██▒ ░  ░░▒████▓  ▓█   ▓██▒ ▒██▒ ░ ░▒████▒
░▒▓▒ ▒ ▒ ▒▓▒░ ░  ░ ▒▒▓  ▒  ▒▒   ▓▒█░ ▒ ░░   ░░ ▒░ ░
░░▒░ ░ ░ ░▒ ░      ░ ▒  ▒   ▒   ▒▒ ░   ░     ░ ░  ░
 ░░░ ░ ░ ░░        ░ ░  ░   ░   ▒    ░         ░   
   ░                 ░          ░  ░           ░  ░
                   ░                               
	
	""")
    print("""
\33[1;32m▛▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▜ 
\33[1;32m▋ \33[1;31m>\33[1;35m ISSAM SARA                             \33[1;32m ▐        
\33[1;32m▋ \33[1;31m>\33[1;35m TOOL TERMUX AND KALI                   \33[1;32m ▐     
\33[1;32m▋ \33[1;31m>\33[1;35m telegram : @I_Sexe1                    \33[1;32m ▐
\33[1;32m▋ \33[1;31m>\33[1;35m HACKED                                 \33[1;32m ▐
\33[1;32m▙▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▟  
""")
    print(R+'[#] '+G+'update ')
    print(R+"[1] "+B+"Termux update")
    print(R+"[2] "+B+"Kali lunx update ")
    print(R+"————————————————————")
    xx = input (R+"[*]"+O+" Enter Namber >> ")
    time.sleep(1)
    if xx == '1':
        os.system('clear')
        print(bnr1)
        os.system('pkg update -y')
        os.system('pkg upgrade -y')
        #os.system('pkg update')
       # os.system('pkg upgrade')
        os.system('''
pkg update -y
pkg upgrade -y
pkg install python2 -y
pkg install python2-dev -y
pkg install python3 -y
pkg install java -y
pkg install fish -y
pkg install ruby -y
pkg install help -y
pkg install git -y
pkg install host -y
pkg install php -y
pkg install perl -y
pkg install nmap -y
pkg install bash -y
pkg install clang -y
pkg install nano -y
pkg install w3m -y
pkg install havij -y
pkg install hydra -y
pkg install figlet -y
pkg install cowsay -y
pkg install curl -y
pkg install tar -y
pkg install zip -y
pkg install unzip -y
pkg install tor -y
pkg install google -y
pkg install sudo -y
pkg install wget -y
pkg install wireshark -y
pkg install wgetrc -y
pkg install wcalc -y
pkg install bmon -y
pkg install vpn -y
pkg install unrar -y
pkg install toilet -y
pkg install proot -y
pkg install net-tools -y
pkg install golang -y
pkg install chroot -y
termux-chroot -y
pkg install macchanger -y
pkg install openssl -y
pkg install cmatrix -y
pkg install openssh -y
pkg install wireshark -y
termux-setup-storage -y
pkg install macchanger -y
apt update && apt upgrade
python3 go.py''')
        
    if xx == '2':
        os.system('clear')
        print(bnr1)
        os.system('apt update -y')
        os.system('apt upgrade -y')
        os.system('apt update')
        os.system('apt upgrade')
        os.system('''
apt update -y
apt upgrade -y
apt install python2 -y
apt install python2-dev -y
apt install python3 -y
apt install java -y
apt install fish -y
apt install ruby -y
apt install help -y
apt install git -y
apt install host -y
apt install php -y
apt install perl -y
apt install nmap -y
apt install bash -y
apt install clang -y
apt install nano -y
apt install w3m -y
apt install havij -y
apt install hydra -y
apt install figlet -y
apt install cowsay -y
apt install curl -y
apt install tar -y
apt install zip -y
apt install unzip -y
apt install tor -y
apt install google -y
apt install sudo -y
apt install wget -y
apt install wireshark -y
apt install wgetrc -y
apt install wcalc -y
apt install bmon -y
apt install vpn -y
apt install unrar -y
apt install toilet -y
apt install proot -y
apt install net-tools -y
apt install golang -y
apt install chroot -y
termux-chroot -y
apt install macchanger -y
apt install openssl -y
apt install cmatrix -y
apt install openssh -y
apt install wireshark -y
termux-setup-storage -y
apt install macchanger -y
apt update && apt upgrade
python3 go.py''')
        
    if xx != '1' and xx != '2':
        os.system('clear')
        while tool():
            print("ddddd")

tool()
